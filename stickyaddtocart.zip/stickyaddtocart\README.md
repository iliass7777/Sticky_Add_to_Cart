# Sticky Add to Cart - PrestaShop 1.7 Module

Module professionnel pour PrestaShop 1.7 qui ajoute un bouton "Ajouter au panier" fixe en bas de l'écran sur les pages produits.

## 📋 Caractéristiques

- ✅ 100% compatible PrestaShop 1.7
- ✅ Bouton fixe en bas de l'écran
- ✅ Ajout au panier en AJAX (sans rechargement de page)
- ✅ Design responsive (mobile + desktop)
- ✅ Animations fluides
- ✅ Message de confirmation
- ✅ Utilise les hooks officiels PrestaShop
- ✅ Ne modifie pas le core de PrestaShop
- ✅ Code commenté et optimisé

## 📦 Installation

### Méthode 1 : Via le Back Office (Recommandé)

1. Téléchargez le module complet
2. Créez un fichier ZIP du dossier `stickyaddtocart`
3. Connectez-vous à votre Back Office PrestaShop
4. Allez dans **Modules** > **Module Manager**
5. Cliquez sur **Upload a module**
6. Sélectionnez le fichier ZIP
7. Cliquez sur **Installer**

### Méthode 2 : Via FTP

1. Téléchargez le dossier `stickyaddtocart`
2. Uploadez-le dans `/modules/` de votre installation PrestaShop
3. Allez dans **Modules** > **Module Manager**
4. Recherchez "Sticky Add to Cart"
5. Cliquez sur **Installer**

## 🎯 Utilisation

Une fois installé, le module fonctionne automatiquement :

- Le bouton apparaît après avoir scrollé 300px sur une page produit
- Il reste fixé en bas de l'écran
- Un clic ajoute le produit au panier en AJAX
- Un message de confirmation s'affiche

Aucune configuration n'est nécessaire !

## 📁 Structure du Module

```
stickyaddtocart/
├── stickyaddtocart.php          # Fichier principal du module
├── index.php                     # Sécurité
├── views/
│   ├── css/
│   │   ├── stickyaddtocart.css  # Styles
│   │   └── index.php
│   ├── js/
│   │   ├── stickyaddtocart.js   # JavaScript AJAX
│   │   └── index.php
│   ├── templates/
│   │   ├── hook/
│   │   │   ├── sticky-button.tpl # Template Smarty
│   │   │   └── index.php
│   │   └── index.php
│   └── index.php
└── translations/
    └── index.php
```

## 🔧 Hooks Utilisés

- `displayHeader` : Chargement des fichiers CSS et JS
- `displayFooterProduct` : Affichage du bouton sur les pages produits

## 🎨 Personnalisation

### Modifier les couleurs

Éditez `views/css/stickyaddtocart.css` :

```css
.sticky-add-btn {
  background-color: #25b9d7; /* Couleur principale */
}

.sticky-add-btn:hover {
  background-color: #1fa3bf; /* Couleur au survol */
}
```

### Modifier le seuil de scroll

Éditez `views/js/stickyaddtocart.js` :

```javascript
const SCROLL_THRESHOLD = 300; // Pixels avant affichage
```

### Modifier la durée du message de succès

Éditez `views/js/stickyaddtocart.js` :

```javascript
const SUCCESS_MESSAGE_DURATION = 3000; // Millisecondes
```

## 🌐 Compatibilité

- **PrestaShop** : 1.7.0.0 et supérieur
- **PHP** : 5.6 et supérieur
- **Navigateurs** : Chrome, Firefox, Safari, Edge (versions récentes)
- **Responsive** : Mobile, Tablette, Desktop

## 📝 Bonnes Pratiques Respectées

- ✅ Utilisation des hooks officiels
- ✅ Chargement des assets via `registerStylesheet` et `registerJavascript`
- ✅ Fichiers `index.php` dans tous les dossiers
- ✅ Code commenté en français et anglais
- ✅ Respect des standards PrestaShop
- ✅ Vanilla JavaScript (pas de dépendance jQuery)
- ✅ Intégration avec le système de panier PrestaShop

## 🐛 Dépannage

### Le bouton n'apparaît pas

1. Vérifiez que le module est bien installé et activé
2. Videz le cache PrestaShop (Paramètres avancés > Performances)
3. Vérifiez que vous êtes sur une page produit
4. Scrollez au moins 300px vers le bas

### L'ajout au panier ne fonctionne pas

1. Vérifiez la console JavaScript (F12) pour les erreurs
2. Assurez-vous que PrestaShop est en version 1.7+
3. Vérifiez que le produit est disponible en stock

## 📄 Licence

MIT License - Libre d'utilisation et de modification

## 👨‍💻 Support

Pour toute question ou problème, n'hésitez pas à ouvrir une issue.

## 🚀 Améliorations Futures

- [ ] Configuration depuis le Back Office
- [ ] Support des variantes de produits
- [ ] Sélecteur de quantité
- [ ] Animations personnalisables
- [ ] Multi-langues avancé

---

**Version** : 1.0.0  
**Auteur** : Your Name  
**Compatible** : PrestaShop 1.7+
